/* 
 * File:   SBPcommunication.h
 * Author: dimit
 *
 * Created on December 14, 2016, 2:21 PM
 */

#ifndef SBP_COMMUNICATION_H
#define SBP_COMMUNICATION_H

#include "siding.h"
#include "wagon.h"
#include "tcp_client.h"

#include <string> 
#include <cstdlib> 
#include "boost/algorithm/string.hpp"//using for trim() and contains()
#include <boost/tokenizer.hpp>

#define HEADSHUNT 0

class SBPcommunication {
public:
    SBPcommunication(); //constructor
    ~SBPcommunication(); //destructor

    //processes the received message
    void HandleMessage(std::vector<Siding> &sidings, const int num_sidings,
            std::string message, std::string send_msg); //, int &moved_wagons, int &last_siding);

    //take from siding insert into headshunt
    void Take(std::vector<Siding> &sidings, const int current_siding,
            const int num_sidings);

    //take from headshunt insert into siding
    void Put(std::vector<Siding> &sidings, const int current_siding,
            const int num_sidings);

    //this function is sending and receiving messages to/from the server
    void Chat(std::vector<Siding> &sidings, const int num_sidings);
    
    //prints the current state of the sidings and their wagons
    void PrintRailway(std::vector<Siding> &sidings, const int num_sidings);

    //prints the error
    void PrintTheError(std::string message);

    //generate take and put messages from the user input
    void GenerateMoveMessage(std::string * converted_msg, char * output_msg, int &message_number);

    //splits the user input into array of strings
    void SplitUserInput(std::string * message, std::string user_input);
};

#endif /* SBP_COMMUNICATION_H */

