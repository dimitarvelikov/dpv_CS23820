/* 
 * File:   railwayInitializer.h
 * Author: dimit
 *
 * Created on December 14, 2016, 2:01 PM
 */

#ifndef RAILWAY_INITIALIZER_H
#define RAILWAY_INITIALIZER_H
#include <string> 
#include <cstdlib> 
#include <iostream>
#include <fstream>//read file
#include "boost/algorithm/string.hpp"// trim() and contains()
#include <boost/tokenizer.hpp>

#include "siding.h"
#include "wagon.h"

class railwayInitializer {
public:
    //constructor
    railwayInitializer();
    
    //destructor
    ~railwayInitializer();
    
    //read file return content
    std::string GetFileContent(std::string const file_name);
    
    //go trough a string, containing wagon data and populate a vector of wagons 
    void CreateWagons(std::string str, std::vector<vehicle *> &wagons);
    
    //go trough a string containing siding data and populate a vector of sidings
    void InitializeSidings(std::string s, std::vector<Siding> &sidings,
            std::vector<vehicle *> &wagons);
    
    //get number of sidings - match the newline characters in a txt file
    int GetNumberOfSidings(std::string sidings_file);


};

#endif /* RAILWAY_INITIALIZER_H */

