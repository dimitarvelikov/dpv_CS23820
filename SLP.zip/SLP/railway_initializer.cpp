/* 
 * File:   railwayInitializer.cpp
 * Author: dimit
 * 
 * Created on December 14, 2016, 2:01 PM
 */

#include "railway_initializer.h"
using namespace std;
using namespace boost;

/*constructor*/
railwayInitializer::railwayInitializer() {
}

/*destructor*/
railwayInitializer::~railwayInitializer() {
}

/*this function accepts a param - string file_name reads a file and 
 *returns the file content*/
string railwayInitializer::GetFileContent(string const file_name) {

    ifstream inFile; //file stream
    inFile.open(file_name); // open the input file

    stringstream strStream; //string stream
    strStream << inFile.rdbuf(); // read the file

    string str = strStream.str(); // str holds the content of the file
    inFile.close(); //close file stream
    return str; //return the file content
}

/* this function reads wagons-data.txt and inserts each vehicle in a vector
 * this vector is used later for populating the sidings */
void railwayInitializer::CreateWagons(string str, vector<vehicle *> &wagons) {

    string wagon_data[3]; //store the data for the constructor of vehicle here
    string next; // each state of the tokenizer is assigned here
    int counter = 0;

    escaped_list_separator<char> els("", ",\n", "\"\'"); //split instructions
    tokenizer<escaped_list_separator<char>> tok(str, els);
    //loop until the end of file (in this case - string)
    for (tokenizer<escaped_list_separator<char>>::iterator beg = tok.begin();
            beg != tok.end(); ++beg) {
        next = *beg;
        boost::trim(next);
        ++counter;
        switch (counter) {
            case 1://vehicle - serial_number
                wagon_data[counter] = next;
                break;
            case 2://vehicle - owner
                wagon_data[counter] = next;
                break;
            case 3://goods + object creation
                vehicle *w = new Wagon(stoi(wagon_data[1]), wagon_data[2], next);
                wagons.push_back(w); //add the vehicle to the vector
                counter = 0;
                break;
        }
    }
}

/*process the string with  wagon-positions.txt content
 *used boost tokenizer to split into strings by space characters */
void railwayInitializer::InitializeSidings(string sidings_content, vector<Siding> &sidings,
        vector<vehicle *> &wagons) {
    int count = 0;
    tokenizer<> tok(sidings_content); //declare the tokenizer
    string temp;
    int num_wagons = 0;
    int curr_siding = 0;
    int curr_siding_id = 0;

    for (tokenizer<>::iterator it = tok.begin(); it != tok.end(); ++it) {
        temp = *it;
        ++count;

        if (count == 1) { // siding size
            sidings[curr_siding].SetSize(std::stoi(temp));
        } else if (count == 2) { // siding free space
            num_wagons = stoi(temp);
            sidings[curr_siding].SetFreeSpace(
                    (sidings[curr_siding].GetSize() - num_wagons));
            //if the siding has 0 wagons reset the counter 
            if (sidings[curr_siding].GetSize() ==
                    sidings[curr_siding].getFreeSpace()) {
                count = 0;
                ++curr_siding;
            }
            // add wagons
        } else if (count > 2) {//new vehicle
            curr_siding_id = stoi(temp);
            for (size_t x = 0; x < wagons.size(); ++x) {
                //search for the correct wagon in the vector of wagons
                //created using wagons-data.txt and add it to the siding
                if (wagons.at(x)->getSerialNumber() == curr_siding_id) {
                    sidings[curr_siding].AddWagon(wagons.at(x));
                }
            }
            // if there are no more wagons reset the counter, go to the next siding
            num_wagons--;
            if (num_wagons < 1) {
                ++curr_siding;
                count = 0;
            }
        }
    }
}

/* count the newline character matches in a string 
 * the string is content of wagon_positions.txt
 * each newline character is a new siding
 * as long as the software stores the sidings in vectors this function is not essential
 * it would be more useful for array of siding objects*/
int railwayInitializer::GetNumberOfSidings(string sidings_file) {
    int num_sidings = 1;
    int length = sidings_file.length();
    for (int i = 0; i < length; ++i) {
        if (sidings_file[i] == '\n')
            ++num_sidings; //if there is a newline char - there is new siding
    }
    return num_sidings;
}
