/* 
 * File:   main.cpp
 * Author: dpv
 *
 * Created on November 23, 2016, 9:11 PM
 */

#include "railway_initializer.h"
#include "SBP_communication.h"

using namespace std;

/*function declaration of PrintSidings()*/
void PrintSidings(std::vector<Siding> &sidings, const int num_sidings);

/*main function*/
int main(int argc, char** argv) {
    
    railwayInitializer * railway = new railwayInitializer();

    SBPcommunication * communication = new SBPcommunication();

    vector<vehicle *> wagons;
    // read  wagons data file
    railway->CreateWagons(railway->GetFileContent("wagons-data.txt"), wagons);
    
    string wagons_positions = "wagon_positions1.txt";

    cout << "Enter a wagons positions filename: ";
    //get the desired filename
    getline(cin, wagons_positions);
    //read the file and assign its content into a string
    wagons_positions = railway->GetFileContent(wagons_positions);

    // return the number of sidings
    const int num_sidings = railway->GetNumberOfSidings(wagons_positions);

    // create array of siding objects using number of sidings
    vector<Siding> sidings(num_sidings);

    // read the file with sidings and wagons data and make changes
    railway->InitializeSidings(wagons_positions, sidings, wagons);

    //print the data about each siding + vehicles
    PrintSidings(sidings, num_sidings);

    //print a (sort of) map of the current state
    //of the sidings and position of vehicles
    communication->PrintRailway(sidings, num_sidings);

    //start communication with the SBP(server)
    communication->Chat(sidings, num_sidings);

    // print the latest positions of the wagons after the end of the
    // communication
    PrintSidings(sidings, num_sidings);

    //clear the vector of wagons
    wagons.clear();

    return 0;
}

/*print information about each siding and its vehicles*/
void PrintSidings(vector<Siding> &sidings, const int num_sidings) {

    cout << endl << "Here are the sidings" << endl;
    for (int x = 0; x < num_sidings; ++x) {
        cout << sidings[x]; //object stream for sidings
        for (size_t i = 0; i < sidings[x].GetAllWagons().size(); ++i) {
            auto *current_vehicle = dynamic_cast<Wagon *> (sidings[x].GetAllWagons().at(i));
            cout << *current_vehicle;
        }
    }
}