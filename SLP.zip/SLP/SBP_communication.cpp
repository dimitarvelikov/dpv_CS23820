/* 
 * File:   SBPcommunication.cpp
 * Author: dimit
 * 
 * Created on December 14, 2016, 2:21 PM
 */

#include "SBP_communication.h"

using namespace std;
using namespace boost;

/*empty constructor*/
SBPcommunication::SBPcommunication() {
}

/*destructor*/
SBPcommunication::~SBPcommunication() {
}

/*this function communicates with the server*/
void SBPcommunication::Chat(vector<Siding> &sidings, const int num_sidings) {
    string user_input = "";
    char send_msg [100];
    int move_command = 1; //for the switch statement which generates take/put - 1/2
    string message[4];

    TCPClient client; //instance of clients
    boost::asio::ip::tcp::socket &my_socket =
            client.TcpCommunication(); //get a connectionF
    boost::system::error_code error = boost::asio::error::host_not_found;
    boost::array<char, 128> buf; //boost array 

    // otherwise strange characters at the end of the 1st msg
    memset(buf.data(), 0, sizeof (buf));

    /*read the message which tells about the exit val etc.*/
    my_socket.read_some(boost::asio::buffer(buf), error); //read msg
    cout << buf.data();
    memset(buf.data(), 0, sizeof (buf)); //clear the buf

    for (;;) {
        cout << endl << "\nEnter a new message: ";
        std::getline(std::cin, user_input); //reads a line 

        if (!contains(user_input, "config") && !contains(user_input, "load")
                && !contains(user_input, "quit")&&!contains(user_input, "]!")) {
            //split the message in parts
            SplitUserInput(message, user_input);
            //generate the take message
            move_command = 1;
            GenerateMoveMessage(message, send_msg, move_command);
            //send the take message
            client.WriteMessage(my_socket, send_msg, error);
            //wait for reply for the take message
            my_socket.read_some(boost::asio::buffer(buf), error);

            HandleMessage(sidings, num_sidings, buf.data(), send_msg);
            sleep(1); //1 sec delay - trying to prevent message corruption
            if (!contains(buf.data(), "-")) {
                memset(buf.data(), 0, sizeof (buf)); //clear the buffer data
                //generate put message
                move_command = 2;
                GenerateMoveMessage(message, send_msg, move_command);
                client.WriteMessage(my_socket, send_msg, error); //send take msg
                //read msg
                my_socket.read_some(boost::asio::buffer(buf), error);
                HandleMessage(sidings, num_sidings, buf.data(), send_msg);
            }
        } else {//if the message is config or load
            client.WriteMessage(my_socket, user_input, error);
            my_socket.read_some(boost::asio::buffer(buf), error);
            if (!contains(buf.data(), "Thank you")) {
                HandleMessage(sidings, num_sidings, buf.data(), send_msg);
            } else {//exit message
                cout << buf.data() << endl;
                break;
            }
        }
        memset(buf.data(), 0, sizeof (buf)); //clear the buffer for the next msg
        PrintRailway(sidings, num_sidings); //print the current state of the sidings
    }
    //close the socket and delete it
    my_socket.shutdown(boost::asio::ip::tcp::socket::shutdown_both);
    my_socket.close();
    delete &my_socket;
}

/*split the user input into array of strings*/
void SBPcommunication::SplitUserInput(string * message, string user_input) {
    int x = 0;
    tokenizer<> tok(user_input);
    for (tokenizer<>::iterator it = tok.begin(); it != tok.end(); ++it) {
        string temp = *it;
        message[x] = temp;
        ++x;
    }
}

/*this function generates 2 kinds of messages for the move command using the user input*/
void SBPcommunication::GenerateMoveMessage(string * converted_msg, char * output_msg, int &message_number) {
    memset(output_msg, 0, 100); //clear the data int output msg
    switch (message_number) {
        case 1://case 1 is take
            strcpy(output_msg, "take ");
            strcat(output_msg, converted_msg[0].c_str());
            strcat(output_msg, " ");
            strcat(output_msg, converted_msg[2].c_str());
            message_number++;
            break;
        case 2://case 2 is put
            strcpy(output_msg, "put ");
            strcat(output_msg, converted_msg[1].c_str());
            strcat(output_msg, " ");
            strcat(output_msg, converted_msg[2].c_str());
            message_number--;
            break;
    }
}

/*this function is handling the take operations 
 it is moving wagon(s) to the headshunt */
void SBPcommunication::Take(vector<Siding> &sidings, const int current_siding,
        const int num_wagons) {
    for (int moved_Wagons = 0; moved_Wagons < num_wagons; ++moved_Wagons) {
        //add wagon to the headshunt
        sidings[HEADSHUNT].GetAllWagons().insert(sidings[HEADSHUNT].GetAllWagons().end()
                , sidings[current_siding].GetAllWagons().front());
        sidings[current_siding].GetAllWagons().erase(
                sidings[current_siding].GetAllWagons().begin());
        //change the free space for the source and destination sidings
        sidings[HEADSHUNT].SetFreeSpace(sidings[HEADSHUNT].getFreeSpace() - 1);
        sidings[current_siding].SetFreeSpace(
                sidings[current_siding].getFreeSpace() + 1);
    }
}

/*check the state of the message and print the appropriate error*/
void SBPcommunication::PrintTheError(string message) {

    if (contains(message, "-1"))
        cout << "ERROR ! - Not enough space." << endl;

    else if (contains(message, "-2"))
        cout << "ERROR ! - Not enough wagons." << endl;

    else if (contains(message, "-3"))
        cout << "ERROR ! - The command referenced a non existent siding." << endl;

    else if (contains(message, "-4"))
        cout << "ERROR ! - Unrecognized message." << endl;
}

/*this function is processing put take and load operations*/
void SBPcommunication::HandleMessage(vector<Siding> &sidings, const int num_sidings,
        string incomming_msg, string sended_msg) {
    cout << "Message received: " << incomming_msg << endl;

    if (!contains(incomming_msg, "Number wagons") && !contains(incomming_msg, "initialized")) {
        string temp = "";
        int current_siding = 0, num_wagons = 0;
        tokenizer<> tok(incomming_msg);
        //split the message in parts
        for (tokenizer<>::iterator it = tok.begin(); it != tok.end(); ++it) {
            ++current_siding;
            temp = *it;
            //second msg is the number of wagons that has to be moved
            if (current_siding == 2) {
                num_wagons = stoi(temp);
            }
        }
        current_siding -= 2; // counts the NORMAL\REVERSE messages

        if (contains(incomming_msg, "-")) {
            PrintTheError(incomming_msg);
        } else {
            if (contains(temp, "NORMAL") && num_sidings == current_siding + 2) {
                ++current_siding;
            }
            if (contains(sended_msg, "put")) {
                Put(sidings, current_siding, num_wagons);
            } else if (contains(sended_msg, "take")) {
                Take(sidings, current_siding, num_wagons);
            }
        }
    }
}

/*take wagons from the headshunt and move them to a siding*/
void SBPcommunication::Put(vector<Siding> &sidings, const int curr_siding,
        const int num_wagons) {

    for (int movedWagons = 0; movedWagons < num_wagons; ++movedWagons) {
        sidings[curr_siding].GetAllWagons().insert(
                sidings[curr_siding].GetAllWagons().begin(), 1,
                sidings[HEADSHUNT].GetAllWagons().back());
        sidings[HEADSHUNT].GetAllWagons().pop_back(); //erase(sidings[HEADSHUNT].GetAllWagons().pop_back();
        sidings[HEADSHUNT].SetFreeSpace(sidings[HEADSHUNT].getFreeSpace() + 1);
        sidings[curr_siding].SetFreeSpace(sidings[curr_siding].getFreeSpace() - 1);
    }
};

/*this function prints the state of the sidings and wagons after each message*/
void SBPcommunication::PrintRailway(vector<Siding> &sidings, const int num_sidings) {

    int curr_siding_space = 0, cur_vehicle = 0;
    int headshunt_size = (sidings[HEADSHUNT].GetSize() * 6);

    cout << endl << "Sidings diagram" << endl;
    for (int x = 0; x < num_sidings; ++x) {
        if (cur_vehicle != 0) {//if this is not the headshunt

            for (int y = 0; y < headshunt_size; ++y) {
                cout << " "; //print 6 space chars for each wagon in the headshunt
            }
            cout << "\\\\" // print \\ to show the begining of the sidings
                    << "-";
            ++headshunt_size; //print next siding 1 char to the right
            //store free space to a variable to prevent multiple checking
            curr_siding_space = sidings[x].getFreeSpace();
            for (int z = 0; z < curr_siding_space; ++z) {
                cout << "------"; //print ---- for each empty space
            }
            //print the serial_no of each vehicle in the siding
            for (size_t z = 0; z < sidings[x].GetAllWagons().size(); ++z) {
                cout << sidings[x].GetAllWagons().at(z)->getSerialNumber();
                if (z != sidings[x].GetAllWagons().size() - 1)
                    cout << "="; //separator between vehicles
            }
            cout << endl;
            ++cur_vehicle;
        } else {//if it is the headshunt
            curr_siding_space = sidings[x].getFreeSpace();
            for (size_t z = 0; z < sidings[x].GetAllWagons().size(); ++z) {
                //print the wagons in the headshunt
                cout << sidings[x].GetAllWagons().at(z)->getSerialNumber();
                if (z != sidings[x].GetAllWagons().size() - 1)
                    cout << "=";
            }
            //print ------ for each free space in the headshunt
            for (int z = 0; z < curr_siding_space; ++z)
                cout << "------";
            cout << "\\\\" << endl;
            ++cur_vehicle; //never get in the else {} again - the headshunt is only 1
        }
    }
};