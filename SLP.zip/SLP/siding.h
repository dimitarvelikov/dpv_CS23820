/*
 * File:   siding.h
 * Author: dpv
 *
 * Created on November 23, 2016, 9:45 PM
 */

#ifndef SIDING_H
#define SIDING_H

#include "vehicle.h"
//#include <vector>

class Siding {
public:
    Siding(int size, int freeSpace, std::vector<vehicle *> wagons);
    
    Siding();//empty constructor
    
    ~Siding(void);//destructor
    
    //sets the size
    void SetSize(int size);
    
    //sets the free space
    void SetFreeSpace(int free_space);
    
    //adds vehicle to the latest position of the vector
    void AddWagon(vehicle *w);
    
    //returns the size
    int GetSize(void);
    
    //returns the free space
    int getFreeSpace(void);
    
    //return the vector of vehicles
    std::vector<vehicle *> &GetAllWagons(void);
    
    //object stream
    friend std::basic_ostream<char> &operator<<(std::basic_ostream<char> &os,
            const Siding &s);
private:
    int size;//siding size
    int free_space;//siding free space
    std::vector<vehicle *> wagons;//siding vector of vehicles
};

#endif /* SIDING_H */