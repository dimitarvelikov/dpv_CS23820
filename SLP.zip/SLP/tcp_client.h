/* 
 * File:   tcpClient.h
 * Author: dimit
 *
 * Created on December 4, 2016, 10:45 AM
 */

#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

#include <boost/array.hpp>
#include <boost/asio.hpp>

#define LAMBPORT "10102"
#define SERVER_NAME "shellsrv.dcs.aber.ac.uk"

class TCPClient {
public:
    boost::asio::ip::tcp::socket* my_socket = NULL;

    TCPClient();
    ~TCPClient();
    boost::asio::ip::tcp::socket & TcpCommunication();
    void WriteMessage(boost::asio::ip::tcp::socket & sock,
            std::string msg, boost::system::error_code error);
    bool CheckForError(boost::system::error_code error);
};

#endif /* TCP_CLIENT_H */

