#include "wagon.h"

using namespace std;

//constructor
Wagon::Wagon(int name, string owner, string goods) : vehicle(name, owner) {
    this-> goods = goods;
};

//empty constructor
Wagon::Wagon() {
};

//destructor
Wagon::~Wagon() {
    // cout << "Wagon destroyed" << endl;
};

//set goods
void Wagon::SetGoods(string goods) {
    this -> goods = goods;
};

//return goods
string Wagon::GetGoods() {
    return goods;
};

//object stream
std::basic_ostream<char>& operator<<(std::basic_ostream<char>& os, const Wagon &w) {
    return os << w.streamHelper() << " Carrying: " << w.goods << endl;
}