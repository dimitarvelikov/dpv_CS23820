#include "siding.h"

using namespace std;

//constructor
Siding::Siding(int size, int free_space, std::vector<vehicle *> wagons) {
    this->size = size;
    this->free_space = free_space;
}

/* empty constructor */
Siding::Siding() {
}

//destructor
Siding::~Siding() {
    //destroy all wagons in the vector
    for (auto &w : wagons) {
        delete w;
    }
    //  cout << "Siding destroyed" << endl;
}

//set size of the siding
void Siding::SetSize(int size) {
    this->size = size;
}

//sets the freespace of the sidings
void Siding::SetFreeSpace(int free_space) {
    this->free_space = free_space;
}

/*starts with lowercase because this function name
 *fails compilation in MS VS17*/
int Siding::getFreeSpace() {
    return free_space;
}

//return the size of the siding
int Siding::GetSize() {
    return size;
}

//add wagon at the latest position of the vector
void Siding::AddWagon(vehicle *new_wagon) {
    wagons.push_back(new_wagon);
}


//return the vector of wagons
std::vector<vehicle *> &Siding::GetAllWagons() {
    return wagons;
}

//object stream
std::basic_ostream<char>& operator<<(std::basic_ostream<char>& os,
        const Siding &s) {
    return os << "Siding of capacity: " << s.size << " number of wagons "
            << s.size - s.free_space << endl;
}