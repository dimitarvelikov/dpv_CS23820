#include "tcp_client.h"

using namespace std;
using boost::asio::ip::tcp;

//constructor
TCPClient::TCPClient() {
};

//destructor
TCPClient::~TCPClient() {
    //   std::cout << "EXIT lamb Client ";
};

//returns connected socket
tcp::socket & TCPClient::TcpCommunication() {
    std::cout << "Trying to find " << SERVER_NAME << std::endl;
    try {
        
        //All programs that use asio need to have at least one io_service object
        boost::asio::io_service io_service;
        
        // turn the server name that was specified as a parameter
        //to the application, into a TCP endpoint.
        tcp::resolver resolver(io_service);
        
        //takes a query object and turns it into a list of endpoints
        tcp::resolver::query query(SERVER_NAME, LAMBPORT);
        
        // list of endpoints is returned using an iterato
        tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
        
        //create and connect the socket
        my_socket = new tcp::socket(io_service);
        boost::asio::connect(*my_socket, endpoint_iterator);

        return *my_socket;
        
        //handle any exceptions that may have been thrown.
    } catch (std::exception& e) {
        std::cerr << e.what() << std::endl;
    }
    //The connection is open now return the socket read and respond to the server
    return *my_socket;
}

//When the server closes the connection, the ip::tcp::socket::read_some()
//function will exit with the boost::asio::error::eof error,
//which is how we know to exit the loop
bool TCPClient::CheckForError(boost::system::error_code error) {
    bool is_error = false;
    if (error == boost::asio::error::eof) {
        std::cout << "end of message" << std::endl;
        is_error = true;
        // Connection closed cleanly by peer.
    } else if (error)
        throw boost::system::system_error(error); // Some other error.
    return is_error;
}

//send a message to the server
void TCPClient::WriteMessage(tcp::socket & sock, string msg,
        boost::system::error_code error) {
    boost::asio::write(sock, boost::asio::buffer(msg), error);
}