/* 
 * File:   wagon.h
 * Author: dpv
 *
 * Created on November 23, 2016, 9:45 PM
 */

#ifndef WAGON_H
#define WAGON_H

#include "vehicle.h"
#include <string>
#include <cstdlib>
#include <vector>
#include <iostream>

class Wagon : public vehicle {
public:
    //constructor
    Wagon(const int name, const std::string owner, const std::string goods);
  
    //empty constructor
    Wagon();
    
    //destructor
    ~Wagon();
    
    //setter for goods
    void SetGoods(std::string goods);
    
    //getter for goods
    std::string GetGoods();
    
    //object stream
    friend std::basic_ostream<char> &operator<<(std::basic_ostream<char> &os,
            const Wagon &w);

private:
    std::string goods;
};
#endif /* WAGON_H */

