#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>/*dup, read, sleep, closeS*/

#include "movementCommands.h"

#define error(param) { fprintf(stderr, "Lamb Server program: ");\
                        fprintf param ; }

#define abort(param) { fprintf(stderr, "Lamb Server program: ");\
                        perror (param) ;\
                        exit(1) ; }

#define LAMBPORT 10102 /*the port for student id dpv*/

#define SERVER_EXIT_VAL "]!" /*exit val for both server and client*/
#define CLIENT_EXIT_VAL "quit"/*exit val for client*/

#define TRUE  1
#define FALSE 0

/*returns a binded socket*/
int getSocket(void);


/*communication with multiple clients(not at the sime time)*/
void startServer(const int socketid);


/*read a message*/
void readMsg(int t, char * msg);


/*send a message*/
void writeMsg(int t, char* msg);


/*handles the basic commands put and take*/
void handleMessage(siding * sidings, char * msg, char * sendMsg, const int numSidings, int * clientsConnected);

#endif /* SERVER_H */