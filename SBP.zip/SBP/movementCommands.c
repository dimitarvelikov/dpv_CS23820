#include "movementCommands.h"


/* Put - check if the operation can be done if TRUE
 * Remove wagons from siding 0 - HEADSHUNT
 * and add wagons to the desired siding
 * if FALSE - don't do anything and send back ERROR message*/
void put(siding * sidings, const int numSidings, const int curSiding, const int incrementNum, char * sendMsg) {
   
    int isError = 0;
    int headshuntNumWagons = sidings[0].size - sidings[0].freeSpace;
    int sidingFreeSpace = sidings[curSiding].freeSpace;
    char temp[5] = {'0'};
    strncpy(sendMsg, "STATUS ", sizeof (sendMsg));
    
    if (numSidings < curSiding + 1) {
        isError = 1;
        strncat(sendMsg, ERROR_SIDING_NOT_PRESENT, sizeof (sendMsg));
    } else if (headshuntNumWagons < incrementNum) {
        isError = 1;
        strncat(sendMsg, ERROR_TOO_MUCH_WAGONS, sizeof (sendMsg));
    } else if (sidingFreeSpace < incrementNum) {
        isError = 1;
        strncat(sendMsg, ERROR_NOT_ENOUGH_SPACE, sizeof (sendMsg));
    }

    if (isError != 1) {/*if error dont change positions*/
        snprintf(temp, sizeof (temp), "%d", incrementNum);//int to char
        addWagons(sidings, curSiding, incrementNum); //add wagons
        removeWagons(sidings, HEADSHUNT, incrementNum); //remove wagons
        strncat(sendMsg, temp, sizeof (sendMsg));
    }
    if ((curSiding + 1) < numSidings) {/*if this is not the last siding*/
        for (int x = 1; x < curSiding; ++x) {
            strncat(sendMsg, " NORMAL", sizeof (sendMsg));
        }
        strncat(sendMsg, " REVERSE", sizeof (sendMsg));
    }/*if this is the last siding*/
    if ((curSiding + 1) == numSidings) {
        for (int x = 1; x < curSiding; ++x)
            strncat(sendMsg, " NORMAL", sizeof (sendMsg));
    }
}


/*handles the load message - setting size and freespace for each siding*/
void load(siding * sidings, int numSidings, const int data[], char * sendMsg) {

    char temp[2];
    int countWagons = 0;
    int success = 1;
    /*check if each siding can fit that number of wagons*/
    for (int curSiding = 0; curSiding < numSidings; ++curSiding) {
        if (sidings[curSiding].size < data[curSiding]) {
            success = 0;
        }
    }
    if (!success) {/*if False - return error*/
        strncat(sendMsg, "STATUS", (sizeof (sendMsg)));
        strncat(sendMsg, ERROR_NOT_ENOUGH_SPACE, sizeof (sendMsg));
        printf("\n%s", sendMsg);
    } else if (success) { /*if true apply the changes*/
        for (int curSiding = 0; curSiding < numSidings; ++curSiding) {
            setWagons(sidings, curSiding, data[curSiding]);
            countWagons += data[curSiding];
        }
        snprintf(temp, sizeof (temp), "%d", countWagons);
        strcpy(sendMsg, "Number wagons: ");
        strcat(sendMsg, temp);
        strcat(sendMsg, "\0");
    }
}


/*take operation - check for wagons and space if true
 * get wagons from a siding move them to headshunt
 * if false return error*/
void take(siding * sidings, const int numSidings, const int curSiding, const int wagonsNum, char * sendMsg) {
    
    int headshuntFreeSpace = sidings[0].freeSpace;
    int sidingCurWagons = sidings[curSiding].size - sidings[curSiding].freeSpace;
    int isError = 0;
    char temp[5] = {'0'};
    strncat(sendMsg, "STATUS ", sizeof (sendMsg));
    
    if (curSiding + 1 > numSidings) {
        isError = 1;
        strncat(sendMsg, ERROR_SIDING_NOT_PRESENT, sizeof (sendMsg));
    } else if (sidingCurWagons < wagonsNum) {
        isError = 1;
        strncat(sendMsg, ERROR_TOO_MUCH_WAGONS, sizeof (sendMsg));
    } else if (headshuntFreeSpace < wagonsNum) {
        isError = 1;
        strncat(sendMsg, ERROR_NOT_ENOUGH_SPACE, sizeof (sendMsg));
    }

    if (isError != 1) {/*if there is an error don't change positions*/
        removeWagons(sidings, curSiding, wagonsNum);
        addWagons(sidings, HEADSHUNT, wagonsNum);
        /*convert int to char*/
        snprintf(temp, sizeof (temp), "%d", wagonsNum);
        strncat(sendMsg, temp, sizeof (sendMsg));
    }
    /*if curSiding is not the last siding*/
    if (curSiding + 1 < numSidings) {
        for (int x = 1; x < curSiding; ++x) {
            strncat(sendMsg, " NORMAL", sizeof (sendMsg));
        }
        strncat(sendMsg, " REVERSE", sizeof (sendMsg));
    }
    /*if curSiding is the lastSiding*/
    if (curSiding + 1 == numSidings) {
        for (int x = 1; x < curSiding; ++x)
            strncat(sendMsg, " NORMAL", sizeof (sendMsg));
    }
}


/*print the current state of the sidings*/
void printSidings(siding * sidings, const int numSidings) {
    
    printf("\n The sidings are:");
    for (int x = 0; x < numSidings; ++x) {
        printf("\nSiding: %d, size: %d, free space: %d", x, sidings[x].size, sidings[x].freeSpace);
    }
}