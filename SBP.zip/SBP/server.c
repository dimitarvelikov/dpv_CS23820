#include "server.h"


/*Reads a new message*/
void readMsg(int t, char * msg) {

    FILE *inchannel;
    int newFileDescriptor = dup(t);
    inchannel = fdopen(newFileDescriptor, "r"); /*open stream - read only*/
    /*try to read 100 bytes from the file descriptor and store them in msg*/
    read(newFileDescriptor, msg, 100);
    printf("\nMessage received: %s\n", msg); /*print the message*/
}


/*Sends message to SLP*/
void writeMsg(int t, char *msg) {

    FILE *outchannel;
    printf("\nSending message: %s", msg);
    outchannel = fdopen(t, "w"); /*open file associate stream with it*/
    fprintf(outchannel, "%s", msg);
    fflush(outchannel); /*send a message*/
}


/*server connects to client, send/receive messages, handleMessages()*/
void startServer(const int socketid) {

    siding * allSidings; //pointer to struct of type siding
    int numSidings = 0; /*hold the number of sidings*/
    int msgNum = 0; /*counts the messages used for alloc/realloc memory*/
    int t;
    int clientsConnected = 0; /*is there a connection?*/
    char receiveMsg[100] = ""; //store the received messages
    char sendMsg[100] = ""; //stores the messages that are going to be sent
    listen(socketid, 10); // prepare for incoming connections

    for (;;) {
        /*release the socket for another connection */
        if (clientsConnected < 1) {
            int z; /* Status code */
            int so_reuseaddr = TRUE;
            z = setsockopt(socketid, SOL_SOCKET,
                    SO_REUSEADDR, &so_reuseaddr,
                    sizeof so_reuseaddr);
            printf("setsockopt returned %d\n", z);
            unsigned int len_otherend;
            struct sockaddr_in otherend;
            /*connect to a new client*/
            do {
                errno = 0; // to make sure we don't react to an old error
                len_otherend = sizeof (otherend);
                t = accept(socketid, (struct sockaddr *) & otherend,
                        &len_otherend); /*accept incoming connections*/
            } while (t < 0 && errno == EINTR);

            if (t < 0) {
                error((stderr, " Couldnt accept; waiting..\n"));
                sleep(5);
                continue;
            }
            ++clientsConnected;
            writeMsg(t, "\nEscape character is ]! \nInglenook Sidings dpv");
        }

        /*delete the data from both arrays to prevent message corruption*/
        memset(&receiveMsg[0], 0, sizeof (receiveMsg));
        memset(&sendMsg[0], 0, sizeof (sendMsg));

        readMsg(t, receiveMsg); /*read a message*/

        ++msgNum;
        //reply with msg which the client down
        if (strstr(receiveMsg, SERVER_EXIT_VAL)) {
            writeMsg(t, "Thank you for using this software !");
            break;
        } else if (strstr(receiveMsg, "config")) {
            if (msgNum == 1) {//allocate memory for the sidings
                allSidings = setUpSidings(receiveMsg, &numSidings);
                writeMsg(t, "Sidings initialized");
            } else {//reallocate memory for the sidings
                allSidings = changeSidings(allSidings, receiveMsg, &numSidings);
                writeMsg(t, "Sidings reinitialized");
            }
        } else {//if is not exit or config
            handleMessage(allSidings, receiveMsg, sendMsg, numSidings, &clientsConnected);
            writeMsg(t, sendMsg);
        }
    }
    close(t); //close and destroy socket
    free(allSidings); // release the memory allocated for the sidings
}


/*process the message and check for errors*/
void handleMessage(siding * sidings, char *msg, char * sendMsg, const int numSidings, int * clientsConnected) {
    
    printf("isnide handle");
    int data[5]; /*used for sscanf - splitting the msg*/
    int numIntsInMsg = 0; /*used for load*/
    printf("\n\n The message  is: %s", msg); /*prints the arrived msg*/
    if (strstr(msg, CLIENT_EXIT_VAL)) {
        *clientsConnected = 0;
        strncpy(sendMsg, "Thank you for using this software !", 40 * sizeof (char));
        //shut both server and client down
    } else if (strstr(msg, "put")) {
        //%*s skips the first string in this case put
        sscanf(msg, "%*s %d %d", &data[0], &data[1]);
        put(sidings, numSidings, data[0], data[1], sendMsg);
    } else if (strstr(msg, "take")) {
        sscanf(msg, "%*s %d %d %d %d", &data[0], &data[1]);
        take(sidings, numSidings, data[0], data[1], sendMsg);
    } else if (strstr(msg, "load")) {
        /*sscanf scan the sidings data - return the number of sidings*/
        numIntsInMsg = sscanf(msg, "%*s %d %d %d %d %d %d ", &data[0], &data[1], &data[2], &data[3], &data[4], &data[5]);
        if (numSidings == numIntsInMsg) {
            load(sidings, numSidings, data, sendMsg);
        } else if (numSidings != numIntsInMsg) {

            printf("\n The number of values doesn't match the number of sidings: %d", numIntsInMsg);
            //unrecognized siding
            strncat(sendMsg, "STATUS", sizeof (sendMsg));
            strncat(sendMsg, ERROR_SIDING_NOT_PRESENT, sizeof (sendMsg));
        }
    }
    printSidings(sidings, numSidings); /*print the current state of the structs*/
}


/*return socket which is later used for establishing connections*/
int getSocket() {

    struct sockaddr_in ourself;
    int socketid = -1;

    /*create a communications endpoint*/
    socketid = socket(AF_INET, SOCK_STREAM, 0);

    if (socketid < 0)
        abort(" Couldnt create socket. ");

    int z; /* Status code */
    int so_reuseaddr = TRUE;

    /*set appropriate socket options*/
    z = setsockopt(socketid, SOL_SOCKET, SO_REUSEADDR, &so_reuseaddr, sizeof so_reuseaddr);

    ourself.sin_family = AF_INET;
    ourself.sin_addr.s_addr = INADDR_ANY;
    ourself.sin_port = htons(LAMBPORT);

    /* associate addresses with a socket*/
    if (bind(socketid, (struct sockaddr *) & ourself, sizeof (ourself)) < 0) {
        (void) close(socketid);
        abort(" Couldn't bind to socket error ");
    }
    return socketid;
}