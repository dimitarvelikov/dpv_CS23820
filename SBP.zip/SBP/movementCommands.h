/* 
 * File:   movement.h
 * Author: dpv
 *
 * Created on November 23, 2016, 9:06 PM
 */
#ifndef MOVEMENTCOMMANDS_H
#define MOVEMENTCOMMANDS_H

#include "changePositions.h"


/*definition of the index of headshunt - always 0*/
#define HEADSHUNT 0 

/*definition of possible errors*/
#define ERROR_NOT_ENOUGH_SPACE "-1"  
#define ERROR_TOO_MUCH_WAGONS "-2"   
#define ERROR_SIDING_NOT_PRESENT "-3"   
#define ERROR_UNRECOGNIZED_INPUT "-4"   


/*check for error, take a wagon from headshunt and puts it in a siding*/
void put(siding * sidings, const int numSidings, const int curSiding, const int wagonsNum, char * sendMsg);


/*check for error, take a wagon(s) from a siding and put it/them in the headshunt */
void take(siding * sidings, const int numSidings, const int curSiding, const int wagonsNum, char *sendMsg);


/*check for error, load wagons in each siding */
void load(siding * sidings, const int numSidings, const int data[], char * sendMsg);


/*print the current state of each siding*/
void printSidings(siding * sidings, const int numSidings);


#endif /* MOVEMENTCOMMANDS_H */