#include "server.h"

/*this is the main function*/
int main(int argc, char** argv) {

    /*bind a socket return it and wait for connection*/
     startServer(getSocket());

    return (EXIT_SUCCESS);
}