#include "changePositions.h"


/* This function is initializing the siding 
 * setting size and free space for each siding*/
siding* setUpSidings(char* msg, int * numSidings) {
    
    int data[10];
    printf("\n%s\n", msg);
    *(numSidings) = sscanf(msg, "%*s%d%d%d%d%d%d%d%d%d", &data[0],
            &data[1], &data[2], &data[3], &data[4],
            &data[5], &data[6], &data[7], &data[8]);
    printf("inside setup num sidings:  %d\n", *numSidings);
    siding* sidings = malloc(*numSidings * (sizeof (sidings)));
    for (int x = 0; x < *numSidings; ++x) {
        sidings[x].size = data[x];
        sidings[x].freeSpace = data[x];
        printf("\nSidings size: %d free space is: %d", sidings[x].size, sidings[x].freeSpace);
    }
    return sidings;
}


/*similar to setUpSidings - used to reallocate already allocated memory*/
siding* changeSidings(siding * sidings, char * msg, int * numSidings) {
    
    int data[10];
    printf("\n%s\n", msg);
    *(numSidings) = sscanf(msg, "%*s%d%d%d%d%d%d%d%d%d", &data[0],
            &data[1], &data[2], &data[3], &data[4],
            &data[5], &data[6], &data[7], &data[8]);
    printf("inside setup num sidings:  %d\n", *numSidings);
    sidings = realloc(sidings, *numSidings * (sizeof (sidings)));
    for (int x = 0; x < *numSidings; ++x) {
        sidings[x].size = data[x];
        sidings[x].freeSpace = data[x];
        printf("\nSidings size: %d free space is: %d", sidings[x].size, sidings[x].freeSpace);
    }
    return sidings;
}


/*Add wagons to the specified siding*/
void addWagons(siding * sidings, const int curSideNum, const int wagonsNum) {
    
    sidings[curSideNum].freeSpace -= wagonsNum;
}


/*Remove wagons from the specified siding*/
void removeWagons(siding * sidings, const int curSideNum, const int wagonsNum) {
    
    sidings[curSideNum].freeSpace += wagonsNum;
}


/*Sets the number of free space in a siding*/
void setWagons(siding * sidings, const int curSideNum, const int wagonsNum) {
    
    sidings[curSideNum].freeSpace = sidings[curSideNum].size - wagonsNum;
}
