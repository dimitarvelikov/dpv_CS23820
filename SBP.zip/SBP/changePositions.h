/* 
 * File:   chanePositions.h
 * Author: dimit
 *
 * Created on December 15, 2016, 3:58 PM
 */

#ifndef CHANEPOSITIONS_H
#define CHANEPOSITIONS_H


#include <stdio.h>/*printf, scanf sscanf*/
#include <stdlib.h>/*malloc, realloc*/
#include <string.h>/*strncpy, strncat, strstr*/


/*define a type - siding*/
typedef struct siding {
    int size; /*size of the siding*/
    int freeSpace; /*free space of the siding*/
} siding;


/*allocate memory for the sidings*/
siding* setUpSidings(char * receiveMsg, int * numSidings);

/*reallocate memory for the sidings*/
siding* changeSidings(siding * sidings, char * msg, int * numSidings);

/*basic operations add/remove/set wagons from sidings*/
void addWagons(siding * sidings, const int currSideNum, const int wagonsNum);

void removeWagons(siding * sidings, const int currSideNum, const int wagonsNum);

void setWagons(siding * sidings, const int currSideNum, const int wagonsNum);

#endif /* CHANEPOSITIONS_H */

